import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'fs'
// After build, inline JS+CSS into dist/index.html so it opens by double-click (file://) too.
const inline=()=>({name:'inline',apply:'build',closeBundle(){
 const d='dist',h=fs.readFileSync(d+'/index.html','utf8');const f=fs.readdirSync(d+'/assets')
 const js=fs.readFileSync(d+'/assets/'+f.find(x=>x.endsWith('.js')),'utf8').replace(/<\/script/g,'<\\/script'),css=fs.readFileSync(d+'/assets/'+f.find(x=>x.endsWith('.css')),'utf8')
 const out=h.replace(/<script type="module"[^>]*><\/script>/,'').replace(/<link rel="stylesheet"[^>]*>/,'').replace('</head>',()=>'<style>'+css+'</style></head>').replace('</body>',()=>'<script>'+js+'</script></body>')
 fs.writeFileSync(d+'/index.html',out)}})
export default defineConfig({plugins:[react(),inline()],base:'./',build:{cssCodeSplit:false,rollupOptions:{output:{format:'iife',inlineDynamicImports:true}}}})
