# PHOTOHUB — Premium Photography Marketplace
Static React + Vite demo. All data (cart, likes, orders, uploads, profile) lives in `localStorage`. **Payment is demo only.**

    npm install
    npm run dev        # local
    npm run deploy     # builds and publishes /dist to the gh-pages branch

Uses `HashRouter` and `base: './'`, so it works on any GitHub Pages path with no extra config.
Demo images load from picsum.photos; replace `src/data/photos.js` URLs with files in `public/images/` for your own photos.
Uploaded photos are resized to 1600px and stored as data URLs (localStorage ~5 MB limit).

## Admin
Only the admin can upload, edit, delete photos, open the dashboard and edit the profile.
Login: `/#/admin` — password is set in `src/data/photos.js` (`ADMIN_PASSWORD`).
Note: on a static GitHub Pages site this check runs in the browser, so it is a demo gate, not real security. Real protection needs a backend.
