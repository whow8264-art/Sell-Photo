const rows=[
['Golden Hour over Angkor','Landscape','sunset,landscape,temple,travel',45],
['Mekong Dawn','Nature','sunrise,river,nature,mist',25],
['Quiet Portrait','Portrait','portrait,studio,light',60],
['Night Market Neon','Street','street,night,city,neon',30],
['Glass Tower Study','Architecture','architecture,glass,city',55],
['Phnom Penh Rooftops','Travel','travel,city,sunset',20],
['Blue Hour Harbor','Night','night,harbor,blue',40],
['Ink in Water','Abstract','abstract,color,macro',15],
['Editorial Coat','Fashion','fashion,editorial,studio',70],
['Misty Pine Ridge','Landscape','forest,mist,landscape,nature',35],
['Monsoon Street','Street','rain,street,city',25],
['Marble Staircase','Architecture','architecture,minimal,stairs',50],
['Coastal Cliffs','Travel','sea,cliffs,travel,sunset',65],
['City After Midnight','Night','night,city,lights',45],
['Fern Detail','Nature','nature,macro,green',10],
['Smoke Curves','Abstract','abstract,smoke,dark',20],
['Linen & Light','Fashion','fashion,light,minimal',80],
['Old Town Alley','Street','street,alley,travel',30],
['Desert Lines','Landscape','desert,landscape,sunset,minimal',90],
['Skyline Reflections','Architecture','architecture,reflection,city',100],
['Lotus Pond','Nature','lotus,nature,pond',15],
['Starlit Camp','Night','night,stars,camping',55]]
export const ADMIN_PASSWORD='$ally12345' // client-side check only: visible to anyone who inspects the site code
export const OWNER='Sokha Vireak'
const _demo=rows.map(([title,category,tags,price],i)=>({
 id:'p'+(i+1),title,category,tags:tags.split(','),price,
 description:`${title} — a carefully composed frame, delivered as a high resolution original file.`,
 image:`https://picsum.photos/seed/photohub${i+3}/1100/${i%3===0?1400:i%3===1?800:1000}`,
 full:`https://picsum.photos/seed/photohub${i+3}/2400/${i%3===0?3000:i%3===1?1700:2100}`,
 rating:+(4.5+((i*7)%5)/10).toFixed(1),reviews:20+(i*13)%110,likes:80+(i*37)%400,favorites:20+(i*19)%160,
 views:300+(i*211)%2600,sales:3+(i*5)%26,date:new Date(2026,8,28-i).toISOString(),published:true}))
export const CATEGORIES=['Landscape','Nature','Portrait','Street','Architecture','Travel','Night','Abstract','Fashion','Other']
export const PRICES=Array.from({length:20},(_,i)=>(i+1)*5)

// No demo photos: the catalogue starts empty and only the admin's uploads appear.
export const SEED=[]
export const DEMO_REVIEWS=[]
