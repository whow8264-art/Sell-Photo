import {Link,NavLink,useNavigate} from '../router'
import {useEffect,useState} from 'react'
import {useStore} from '../hooks/useStore'
import {money,fdate,download} from '../utils/helpers'
export const Stars=({v})=><span className="stars" style={{'--p':Math.max(0,Math.min(5,v))/5*100+'%'}} role="img" aria-label={v?`Rated ${v} out of 5`:'No ratings yet'}>★★★★★</span>
export function StarPicker({value,onChange}){const [h,setH]=useState(0);const on=h||value
 return <div className="picker" role="radiogroup" aria-label="Your rating" onMouseLeave={()=>setH(0)}>{[1,2,3,4,5].map(n=><button type="button" key={n} role="radio" aria-checked={value===n} aria-label={`${n} star${n>1?'s':''}`} className={n<=on?'on':''} onMouseEnter={()=>setH(n)} onClick={()=>onChange(n)}>★</button>)}<span className="muted">{value?`${value} / 5`:'Tap a star'}</span></div>}
export const Avatar=({name,src,size=40})=>src?<img className="av" style={{width:size,height:size}} src={src} alt={name}/>:<span className="av" style={{width:size,height:size,fontSize:size/2.4}} aria-hidden>{name[0]}</span>
export function Toast(){const {toast}=useStore();return <div className={'toast'+(toast?' on':'')} role="status" aria-live="polite">{toast}</div>}
export function Empty({text,btn,to}){return <div className="empty"><p>{text}</p>{btn&&<Link className="btn" to={to}>{btn}</Link>}</div>}
export function Modal({children,onClose}){
 useEffect(()=>{const k=e=>e.key==='Escape'&&onClose();addEventListener('keydown',k);return()=>removeEventListener('keydown',k)},[])
 return <div className="scrim" onClick={onClose}><div className="modal" role="dialog" aria-modal="true" onClick={e=>e.stopPropagation()}>{children}</div></div>}
export function Confirm({text,yes='Delete',onYes,onNo}){return <Modal onClose={onNo}><h3>{text}</h3><div className="btns"><button className="btn" onClick={onYes}>{yes}</button><button className="btn out" onClick={onNo}>Cancel</button></div></Modal>}
export const linesOf=(o,photo)=>o.lines||o.items.map(id=>{const p=photo(id);return{id,title:p?p.title:'Photo',price:p?p.price:0}})
export const totalOf=(o,photo)=>linesOf(o,photo).reduce((t,l)=>t+l.price,0)
export function Receipt({o,onClose}){
 const {photo,say,removeOrder}=useStore();const [ask,setAsk]=useState(false);const L=linesOf(o,photo)
 return <Modal onClose={onClose}><div className="rcpt"><div className="logo">PHOTOHUB</div><p className="muted">Receipt · Demo Payment</p>
  <dl className="info"><dt>Order ID</dt><dd>{o.id}</dd><dt>Date</dt><dd>{fdate(o.date)}</dd><dt>Email</dt><dd>{o.email}</dd><dt>Status</dt><dd className="ok">{o.status}</dd></dl>
  {L.map(l=>{const p=photo(l.id);return <div className="line sm" key={l.id}><span>{l.title}</span><b>{money(l.price)}</b>{p&&<button className="btn sm" onClick={()=>download(p.full,l.title,say)}>Download</button>}</div>})}
  <div className="row tot"><span>Total</span><span>{money(totalOf(o,photo))}</span></div><p className="muted" style={{fontSize:'.8rem'}}>Demo payment: no real money was charged.</p>
  <div className="btns"><button className="btn out" onClick={()=>setAsk(true)}>Delete receipt</button><button className="btn" onClick={onClose}>Close</button></div></div>
  {ask&&<Confirm text="Delete this receipt and order?" onYes={()=>{removeOrder(o.id);onClose()}} onNo={()=>setAsk(false)}/>}</Modal>}
export function Lightbox({photos,index,onClose}){
 const {addCart}=useStore();const nav=useNavigate();const [i,setI]=useState(index);const [z,setZ]=useState(false);const n=photos.length
 const go=d=>{setZ(false);setI((i+d+n)%n)}
 useEffect(()=>{const k=e=>{e.key==='Escape'&&onClose();e.key==='ArrowRight'&&go(1);e.key==='ArrowLeft'&&go(-1)};addEventListener('keydown',k);return()=>removeEventListener('keydown',k)})
 const p=photos[i]
 return <div className="scrim lb" onClick={onClose}><div className="lbbar" onClick={e=>e.stopPropagation()}><span>{p.title}</span>
  <span>{p.price&&<><button className="btn sm" onClick={()=>{addCart(p.id);onClose();nav('/checkout')}}>Buy Now · {money(p.price)}</button> <button className="btn sm out" onClick={()=>addCart(p.id)}>Add to Cart</button></>}<button className="ghost" onClick={()=>setZ(!z)}>{z?'Zoom out':'Zoom in'}</button><button className="ghost" onClick={onClose} aria-label="Close">✕</button></span></div>
  {n>1&&<button className="lbnav l" onClick={e=>{e.stopPropagation();go(-1)}} aria-label="Previous">‹</button>}
  <div className={'wm lbimg'+(z?' zoom':'')} onClick={e=>{e.stopPropagation();setZ(!z)}}><img src={p.image} alt={p.title}/></div>
  {n>1&&<button className="lbnav r" onClick={e=>{e.stopPropagation();go(1)}} aria-label="Next">›</button>}</div>}
export function PhotoCard({p}){
 const {s,like,fav}=useStore()
 return <article className="card">
  <Link to={'/photo/'+p.id} className="cimg"><img loading="lazy" src={p.image} alt={p.title}/><span className="ov">View Photo</span></Link>
  <div className="cbody"><h3>{p.title}</h3><div className="row"><span><Stars v={p.rating}/> {p.rating||'New'}</span><b>{money(p.price)}</b></div>
   <div className="row small"><button className={'ic'+(s.likes.includes(p.id)?' on':'')} onClick={()=>like(p.id)} aria-label="Like">❤ {p.likes+(s.likes.includes(p.id)?1:0)}</button>
   <button className={'ic'+(s.favs.includes(p.id)?' on':'')} onClick={()=>fav(p.id)} aria-label="Favorite">★ {p.favorites+(s.favs.includes(p.id)?1:0)}</button></div></div></article>}
export const PhotoGrid=({photos})=><div className="masonry">{photos.map(p=><PhotoCard key={p.id} p={p}/>)}</div>
export function Navbar(){
 const {s,logout,photo}=useStore();const [bell,setBell]=useState(false);const [rc,setRc]=useState(null);const nav=useNavigate();const [open,setOpen]=useState(false);const [q,setQ]=useState('');const [sr,setSr]=useState(false)
 const L=[['/','Home'],['/explore','Explore'],['/my-photos','My Photos'],['/favorites','Favorites'],['/orders','Purchases'],['/reviews','Reviews']]
 const go=e=>{e.preventDefault();nav('/explore?q='+encodeURIComponent(q));setSr(false);setOpen(false)}
 return <><header className="nav"><Link to="/" className="logo">PHOTOHUB</Link>
  <nav className={open?'open':''} aria-label="Main">{L.map(([t,l])=><NavLink key={t} to={t} end={t==='/'} onClick={()=>setOpen(false)}>{l}</NavLink>)}
   <Link className="btn sm" to="/sell" onClick={()=>setOpen(false)}>Sell My Photo</Link><Link className="link" to="/profile" onClick={()=>setOpen(false)}>My Profile</Link>{s.admin?<button className="ghost" onClick={()=>{logout();setOpen(false);nav('/')}}>Admin Logout</button>:<Link className="link" to="/admin" onClick={()=>setOpen(false)}>Admin Login</Link>}</nav>
  <div className="tools">{sr&&<div><input autoFocus onKeyDown={e=>e.key==='Enter'&&go(e)} aria-label="Search photos" placeholder="Search title, category, tag" value={q} onChange={e=>setQ(e.target.value)}/></div>}
   <button className="ghost" onClick={()=>setSr(!sr)} aria-label="Search">⌕</button>
   <button className="ghost bell" onClick={()=>setBell(!bell)} aria-label="Order history" aria-expanded={bell}>🔔{s.orders.length>0&&<em>{s.orders.length}</em>}</button>
   <Link className="ghost cartb" to="/cart" aria-label="Cart">Cart{s.cart.length>0&&<em>{s.cart.length}</em>}</Link>
   <button className="ghost burger" onClick={()=>setOpen(!open)} aria-label="Menu" aria-expanded={open}>☰</button></div></header>
  {bell&&<div className="bellpanel" role="dialog" aria-label="Order history"><div className="row"><b>Order History</b><button className="ghost" onClick={()=>setBell(false)} aria-label="Close">✕</button></div>
   {s.orders.length===0?<p className="muted">No purchase history yet.</p>:s.orders.map(o=><button key={o.id} className="bpitem" onClick={()=>{setRc(o);setBell(false)}}><span><b>{o.id}</b><small>{fdate(o.date)} · Paid (Demo)</small></span><b>{money(totalOf(o,photo))}</b></button>)}
   <Link className="btn sm full" to="/orders" onClick={()=>setBell(false)}>View all purchases</Link></div>}
  {rc&&<Receipt o={s.orders.find(x=>x.id===rc.id)||rc} onClose={()=>setRc(null)}/>}</>}
export const Footer=()=><footer className="foot"><span className="logo">PHOTOHUB</span><p>Demo marketplace. Payments are simulated and no real transactions occur.</p></footer>
