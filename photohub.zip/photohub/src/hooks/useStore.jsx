import {createContext,useContext,useEffect,useState,useRef} from 'react'
import {SEED,OWNER,ADMIN_PASSWORD} from '../data/photos'
const Ctx=createContext()
const load=(k,d)=>{try{const v=JSON.parse(localStorage.getItem('ph_'+k));return v??d}catch{return d}}
export const useStore=()=>useContext(Ctx)
export function Provider({children}){
 const [s,setS]=useState(()=>({photos:load('photos',SEED).filter(p=>!/^p\d+$/.test(p.id)),likes:load('likes',[]),favs:load('favs',[]),cart:load('cart',[]),orders:load('orders',[]),
  comments:load('comments',{}),reviews:load('reviews',{}),helpful:load('helpful',[]),following:load('following',false),admin:load('admin',false),
  profile:load('profile',{name:OWNER,bio:'Cambodia-based photographer chasing honest light. Every frame here is mine, every sale goes straight to the next trip.',avatar:'',followers:1280})}))
 const [toast,setToast]=useState('');const t=useRef()
 useEffect(()=>{for(const k in s){try{localStorage.setItem('ph_'+k,JSON.stringify(s[k]))}catch{}}},[s])
 const set=(k,f)=>setS(p=>({...p,[k]:typeof f==='function'?f(p[k]):f}))
 const say=m=>{setToast(m);clearTimeout(t.current);t.current=setTimeout(()=>setToast(''),2200)}
 const toggle=(k,id,onMsg,offMsg)=>{const on=!s[k].includes(id);set(k,a=>on?[...a,id]:a.filter(x=>x!==id));say(on?onMsg:offMsg)}
 const A={s,set,say,toast,
  like:id=>toggle('likes',id,'Photo liked.','Like removed.'),
  fav:id=>toggle('favs',id,'Photo added to favorites.','Photo removed from favorites.'),
  addCart:id=>{if(s.cart.includes(id))return say('Already in your cart.');set('cart',a=>[...a,id]);say('Photo added to cart.')},
  removeCart:id=>{set('cart',a=>a.filter(x=>x!==id));say('Photo removed from cart.')},
  owned:id=>s.orders.some(o=>o.items.includes(id)),
  patchPhoto:(id,p)=>set('photos',a=>a.map(x=>x.id===id?{...x,...p}:x)),
  view:id=>set('photos',a=>a.map(x=>x.id===id?{...x,views:x.views+1}:x)),
  del:id=>{set('photos',a=>a.filter(x=>x.id!==id));say('Photo deleted.')},
  addPhoto:p=>set('photos',a=>[p,...a]),
  pay:(email)=>{const ids=s.cart.filter(id=>s.photos.some(x=>x.id===id));const lines=ids.map(id=>{const p=s.photos.find(x=>x.id===id);return{id,title:p.title,price:p.price}})
   const o={id:'PH-'+Math.floor(100000+Math.random()*900000),items:ids,lines,email,date:new Date().toISOString(),status:'Paid (Demo)'}
   set('orders',a=>[o,...a]);set('cart',[]);set('photos',a=>a.map(x=>ids.includes(x.id)?{...x,sales:x.sales+1}:x));say('Payment successful.');return o},
  login:pw=>{if(pw.replace(/[\s\u200b]/g,'')===ADMIN_PASSWORD){set('admin',true);say('Welcome, admin.');return true}say('Wrong admin password.');return false},
  logout:()=>{set('admin',false);say('Logged out.')},
  removeOrder:id=>{set('orders',a=>a.filter(o=>o.id!==id));say('Order deleted.')},
  removeOrderItem:(oid,pid)=>{set('orders',a=>a.map(o=>o.id===oid?{...o,items:o.items.filter(x=>x!==pid),lines:o.lines&&o.lines.filter(l=>l.id!==pid)}:o).filter(o=>o.items.length));say('Purchase deleted.')},
  photo:id=>s.photos.find(p=>p.id===id)}
 return <Ctx.Provider value={A}>{children}</Ctx.Provider>}
