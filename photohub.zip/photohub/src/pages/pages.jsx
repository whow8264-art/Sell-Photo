import {Link,useNavigate,useParams,useSearchParams} from '../router'
import {useEffect,useMemo,useState} from 'react'
import {useStore} from '../hooks/useStore'
import {PhotoGrid,Stars,StarPicker,Avatar,Empty,Modal,Lightbox,Confirm,Receipt,linesOf} from '../components/ui'
import {CATEGORIES,PRICES,DEMO_REVIEWS} from '../data/photos'
import {money,fdate,download,resize} from '../utils/helpers'
export function AdminLogin(){const {s,login,logout}=useStore();const [pw,setPw]=useState('');const [show,setShow]=useState(false);const [err,setErr]=useState('');const nav=useNavigate()
 const doLogin=()=>setErr(login(pw)?'':'Wrong password. Check for extra characters or auto-capitalised letters.')
 if(s.admin)return <div className="wrap narrow"><div className="panel center"><h1>Admin</h1><p className="muted">You are signed in. Only the admin can upload and manage photos.</p>
  <div className="btns" style={{justifyContent:'center'}}><button className="btn" onClick={()=>nav('/sell')}>Upload Photo</button><button className="btn out" onClick={()=>nav('/my-photos')}>My Photos</button><button className="btn out" onClick={()=>{logout();nav('/')}}>Logout</button></div></div></div>
 return <div className="wrap narrow"><div className="panel"><h1>Admin Login</h1><p className="muted">Only the admin can upload and manage photos.</p>
  <label>Admin password<input type={show?'text':'password'} autoFocus autoCapitalize="off" autoCorrect="off" autoComplete="off" spellCheck="false" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doLogin()}/></label><label className="chk"><input type="checkbox" checked={show} onChange={e=>setShow(e.target.checked)}/> Show password</label>{err&&<p className="err" role="alert">{err}</p>}<button className="btn full" type="button" onClick={doLogin}>Login</button></div></div>}
export const Guard=({children})=>{const {s}=useStore();return s.admin?children:<AdminLogin/>}
const live=ps=>ps.filter(p=>p.published!==false)
const sum=(a,f)=>a.reduce((t,x)=>t+f(x),0)
const Head=({t,sub,children})=><div className="head"><div><h1>{t}</h1>{sub&&<p className="muted">{sub}</p>}</div>{children}</div>
function stats(ps){const n=ps.length;return{Photos:n,Sales:sum(ps,p=>p.sales),Revenue:money(sum(ps,p=>p.sales*p.price)),Views:sum(ps,p=>p.views).toLocaleString(),Likes:sum(ps,p=>p.likes).toLocaleString(),Rating:n?(sum(ps,p=>p.rating)/n).toFixed(1):'—'}}
const Stats=({keys})=>{const {s}=useStore();const st=stats(s.photos);return <div className="stats">{keys.map(k=><div key={k}><b>{st[k]}</b><span>{k==='Photos'?'Total Photos':k==='Rating'?'Average Rating':'Total '+k}</span></div>)}</div>}
const Section=({t,to,children})=><section className="sec"><div className="head"><h2>{t}</h2>{to&&<Link className="link" to={to}>See all</Link>}</div>{children}</section>

export function Home(){
 const {s}=useStore();const ps=live(s.photos);const nav=useNavigate()
 const feat=[...ps].sort((a,b)=>b.rating-a.rating||b.sales-a.sales).slice(0,4)
 const latest=[...ps].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,8)
 const pop=[...ps].sort((a,b)=>b.likes-a.likes).slice(0,4)
 return <>
 <section className="hero" style={{backgroundImage:`linear-gradient(180deg,rgba(5,6,9,.3),#050609 96%),url(${ps[0]?.full||''})`}}>
  <div className="glow"/><div className="heroin"><h1>Photography Worth Keeping.</h1>
  <p>Discover carefully selected photography and collect images that inspire you.</p>
  <div className="btns"><Link className="btn" to="/explore">Explore Photos</Link><Link className="btn out" to="/sell">Sell My Photo</Link></div></div></section>
 <div className="wrap">
 {ps.length===0?<Empty text="No photos yet. Photos will appear here once the admin uploads them." btn="Sell My Photo" to="/sell"/>:<>
 <Section t="Featured Photos" to="/explore"><PhotoGrid photos={feat}/></Section>
 <Section t="Latest Photos" to="/explore"><PhotoGrid photos={latest}/></Section>
 <Section t="Popular Photos"><PhotoGrid photos={pop}/></Section></>}
 <Section t="My Photography"><div className="owner"><Avatar name={s.profile.name} src={s.profile.avatar} size={96}/><div><h3>{s.profile.name}</h3><p className="muted">{s.profile.bio}</p>
  <Link className="btn out sm" to="/profile">View profile</Link></div></div></Section>
 <section className="cta"><h2>Have a photo worth sharing?</h2><button className="btn" onClick={()=>nav('/sell')}>Sell My Photo</button></section></div></>}

export function Explore(){
 const {s}=useStore();const [sp,setSp]=useSearchParams();const q=sp.get('q')||'';const [cat,setCat]=useState('All');const [sort,setSort]=useState('new')
 const list=useMemo(()=>{const k=q.toLowerCase().trim();let a=live(s.photos).filter(p=>(cat==='All'||p.category===cat)&&(!k||[p.title,p.category,...p.tags].join(' ').toLowerCase().includes(k)))
  return a.sort((x,y)=>sort==='price'?x.price-y.price:sort==='pop'?y.likes-x.likes:new Date(y.date)-new Date(x.date))},[s.photos,q,cat,sort])
 return <div className="wrap"><Head t="Explore" sub={`${list.length} photos`}/>
  <div className="filters"><input aria-label="Search" placeholder="Search by title, category or tag" value={q} onChange={e=>setSp(e.target.value?{q:e.target.value}:{})}/>
   <select aria-label="Sort" value={sort} onChange={e=>setSort(e.target.value)}><option value="new">Newest</option><option value="pop">Most liked</option><option value="price">Price: low to high</option></select></div>
  <div className="chips">{['All',...CATEGORIES].map(c=><button key={c} className={'chip'+(c===cat?' on':'')} onClick={()=>setCat(c)}>{c}</button>)}</div>
  {list.length?<PhotoGrid photos={list}/>:s.photos.length?<Empty text="No photos match your search."/>:<Empty text="No photos yet. Photos appear here once the admin uploads them."/>}</div>}

export function PhotoDetails(){
 const {id}=useParams();const A=useStore();const {s,set,say,like,fav,addCart,owned,view,photo,patchPhoto}=A;const nav=useNavigate();const p=photo(id);const [lb,setLb]=useState(false)
 const [cm,setCm]=useState('');const [rv,setRv]=useState('');const [rt,setRt]=useState(0)
 useEffect(()=>{view(id)},[id])
 if(!p)return <Empty text="This photo isn't available." btn="Explore Photos" to="/explore"/>
 const mine=owned(p.id),cms=s.comments[p.id]||[],rvs=s.reviews[p.id]||[],tot=rvs.length,avg=tot?+(sum(rvs,r=>r.rating)/tot).toFixed(1):0,dist=[5,4,3,2,1].map(n=>tot?Math.round(rvs.filter(r=>r.rating===n).length/tot*100):0)
 const add=(k,o,setter,msg)=>{if(k==='reviews'&&!o.rating)return say('Select a star rating first.');if(!o.text.trim())return say('Write a short comment first.')
  const n={...o,id:Date.now(),name:'You',date:new Date().toISOString()};set(k,m=>({...m,[p.id]:[n,...(m[p.id]||[])]}))
  if(k==='reviews'){const all=[n,...rvs];patchPhoto(p.id,{rating:+(sum(all,r=>r.rating)/all.length).toFixed(1),reviews:all.length});setRt(0)}
  setter('');say(msg)}
 return <div className="wrap"><div className="detail">
  <div className="wm big" onClick={()=>setLb(true)} role="button" tabIndex={0} onKeyDown={e=>e.key==='Enter'&&setLb(true)} aria-label="Open full screen"><img src={p.image} alt={p.title}/></div>
  <aside><h1>{p.title}</h1><div className="row"><Stars v={avg}/><span>{avg||'No ratings yet'}</span><span className="muted">{tot} Reviews</span></div>
   <div className="price">{money(p.price)}</div><p className="muted">by PHOTOHUB</p><p>{p.description}</p>
   <div className="btns"><button className="btn" onClick={()=>{addCart(p.id);nav('/checkout')}}>Buy Now</button><button className="btn out" onClick={()=>addCart(p.id)}>Add to Cart</button></div>
   <div className="btns"><button className={'btn ghostb'+(s.likes.includes(p.id)?' on':'')} onClick={()=>like(p.id)}>❤ Like</button><button className={'btn ghostb'+(s.favs.includes(p.id)?' on':'')} onClick={()=>fav(p.id)}>★ Favorite</button>
   <button className={'btn ghostb'+(s.following?' on':'')} onClick={()=>{set('following',!s.following);say(s.following?'Unfollowed.':'Now following PHOTOHUB.')}}>{s.following?'Following':'Follow'}</button></div>
   <dl className="info"><dt>Format</dt><dd>JPG</dd><dt>Resolution</dt><dd>High Resolution</dd><dt>License</dt><dd>Personal / Digital Photo</dd><dt>Category</dt><dd>{p.category}</dd></dl>
   <div className="chips">{p.tags.map(t=><Link key={t} className="chip" to={'/explore?q='+t}>{t}</Link>)}</div>
   {mine&&<button className="btn" onClick={()=>download(p.full,p.title,say)}>Download Original</button>}</aside></div>
  <section className="sec"><h2>Reviews</h2><div className="revsum"><div className="big5">{avg?<>{avg}<small> / 5</small></>:<small>No ratings yet</small>}<br/><Stars v={avg}/></div>
   <div>{dist.map((d,i)=><div className="bar" key={i}><span>{5-i} Star{i<4?'s':''}</span><i><b style={{width:d+'%'}}/></i><span>{d}%</span></div>)}</div></div>
   {mine?<div className="panel"><p>Your rating</p><StarPicker value={rt} onChange={setRt}/>
    <textarea aria-label="Review" placeholder="Share your thoughts on this photo" value={rv} onChange={e=>setRv(e.target.value)}/><button className="btn sm" onClick={()=>add('reviews',{text:rv,rating:rt},setRv,'Review posted.')}>Post review</button></div>
    :<p className="muted">Purchase this photo to leave a review.</p>}
   <div className="list">{rvs.map(r=><Rev key={r.id} r={r}/>)}</div></section>
  <section className="sec"><h2>Comments</h2><div className="panel"><textarea aria-label="Comment" placeholder="Add a comment" value={cm} onChange={e=>setCm(e.target.value)}/>
   <button className="btn sm" onClick={()=>add('comments',{text:cm},setCm,'Comment posted.')}>Comment</button></div>
   <div className="list">{cms.length===0&&<p className="muted">No comments yet. Start the conversation.</p>}{cms.map(c=><div className="cmt" key={c.id}><Avatar name={c.name} src={s.profile.avatar} size={36}/><div><b>{c.name}</b> <span className="muted">{fdate(c.date)}</span><p>{c.text}</p></div></div>)}</div></section>
  {lb&&<Lightbox photos={[p]} index={0} onClose={()=>setLb(false)}/>}</div>}
function Rev({r}){const {s,set}=useStore();const on=s.helpful.includes(r.id)
 return <div className="panel rev"><div className="who"><Avatar name={r.name} src={r.name==='You'?s.profile.avatar:''} size={36}/><b>{r.name}</b><Stars v={r.rating}/><span className="muted">{fdate(r.date)}</span></div><p>{r.text}</p>
  <button className={'ic'+(on?' on':'')} onClick={()=>set('helpful',a=>on?a.filter(x=>x!==r.id):[...a,r.id])}>Helpful</button></div>}

export function Reviews(){const {s}=useStore();const all=Object.entries(s.reviews).flatMap(([pid,a])=>a.map(r=>({...r,pid})))
 return <div className="wrap"><Head t="Reviews" sub="What buyers say about PHOTOHUB photos."/><div className="list">
  {all.length===0&&<Empty text="No reviews yet. Buyers can review a photo after purchasing it."/>}{all.map(r=><Rev key={r.id} r={r}/>)}</div></div>}

function EditModal({p,onClose}){const {patchPhoto,say}=useStore();const [f,setF]=useState({title:p.title,price:p.price,description:p.description,published:p.published!==false})
 return <Modal onClose={onClose}><h2>Edit photo</h2><label>Title<input value={f.title} onChange={e=>setF({...f,title:e.target.value})}/></label>
  <label>Description<textarea value={f.description} onChange={e=>setF({...f,description:e.target.value})}/></label>
  <label>Price<select value={f.price} onChange={e=>setF({...f,price:+e.target.value})}>{PRICES.map(n=><option key={n} value={n}>${n}</option>)}</select></label>
  <label className="chk"><input type="checkbox" checked={f.published} onChange={e=>setF({...f,published:e.target.checked})}/> Published</label>
  <div className="btns"><button className="btn" onClick={()=>{patchPhoto(p.id,f);say('Photo updated.');onClose()}}>Save changes</button><button className="btn out" onClick={onClose}>Cancel</button></div></Modal>}
export function MyPhotos(){const {s,del}=useStore();const [dl,setDl]=useState(null);const [ed,setEd]=useState(null);const [lb,setLb]=useState(null)
 return <div className="wrap"><Head t="My Photos"><Link className="btn" to="/sell">+ Upload New Photo</Link></Head><Stats keys={['Photos','Sales','Views','Likes','Revenue']}/>
  {s.photos.length===0?<Empty text="You haven't uploaded any photos yet." btn="Upload Your First Photo" to="/sell"/>:
  <div className="manage">{s.photos.map((p,i)=><article className="mcard" key={p.id}><img loading="lazy" src={p.image} alt={p.title} onClick={()=>setLb(i)}/>
   <div><h3>{p.title}</h3><p className="muted">{money(p.price)} · <Stars v={p.rating}/> {p.rating||'New'} · <span className={p.published!==false?'ok':'draft'}>{p.published!==false?'Published':'Draft'}</span></p>
   <p className="muted">{p.views} views · {p.likes} likes · {p.sales} sales</p>
   <div className="btns"><button className="btn sm out" onClick={()=>setEd(p)}>Edit</button><button className="btn sm out" onClick={()=>setDl(p)}>Delete</button><Link className="btn sm" to={'/photo/'+p.id}>View</Link></div></div></article>)}</div>}
  {dl&&<Confirm text={`Delete "${dl.title}"?`} onYes={()=>{del(dl.id);setDl(null)}} onNo={()=>setDl(null)}/>}{ed&&<EditModal p={ed} onClose={()=>setEd(null)}/>}{lb!==null&&<Lightbox photos={s.photos} index={lb} onClose={()=>setLb(null)}/>}</div>}

export function SellPhoto(){
 const {addPhoto,say}=useStore();const nav=useNavigate();const [img,setImg]=useState('');const [drag,setDrag]=useState(false);const [prev,setPrev]=useState(false);const [done,setDone]=useState(false)
 const [f,setF]=useState({title:'',description:'',category:'Landscape',tags:'',price:25});const [err,setErr]=useState('')
 const pick=async file=>{if(!file)return;if(!/image\/(jpeg|png)/.test(file.type))return setErr('Only JPG or PNG files are supported.');setErr('');setImg(await resize(file))}
 const pub=()=>{if(!img)return setErr('Choose a photo first.');if(!f.title.trim())return setErr('Add a title.');if(f.price<5||f.price>100||f.price%5)return setErr('Price must be $5–$100 in $5 steps.')
  addPhoto({id:'u'+Date.now(),...f,tags:f.tags.split(',').map(t=>t.trim().toLowerCase()).filter(Boolean),image:img,full:img,rating:0,reviews:0,likes:0,favorites:0,views:0,sales:0,date:new Date().toISOString(),published:true});say('Photo published successfully.');setDone(true)}
 if(done)return <div className="wrap"><div className="empty"><h2>Your photo has been published successfully.</h2><div className="btns"><Link className="btn" to="/my-photos">View My Photos</Link><button className="btn out" onClick={()=>{setDone(false);setImg('');setF({...f,title:'',description:'',tags:''})}}>Upload another</button></div></div></div>
 return <div className="wrap narrow"><Head t="Sell My Photo"/>
  <label className={'drop'+(drag?' on':'')} onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);pick(e.dataTransfer.files[0])}}>
   {img?<img src={img} alt="Selected photo preview"/>:<><b>Drag &amp; Drop your photo here</b><span>or</span><span className="btn sm">Choose Photo</span><small>JPG / PNG</small></>}
   <input type="file" accept="image/jpeg,image/png" hidden onChange={e=>pick(e.target.files[0])}/></label>
  <label>Photo Title<input value={f.title} onChange={e=>setF({...f,title:e.target.value})}/></label>
  <label>Description<textarea value={f.description} onChange={e=>setF({...f,description:e.target.value})}/></label>
  <div className="two"><label>Category<select value={f.category} onChange={e=>setF({...f,category:e.target.value})}>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></label>
  <label>Price<select value={f.price} onChange={e=>setF({...f,price:+e.target.value})}>{PRICES.map(n=><option key={n} value={n}>${n}</option>)}</select></label></div>
  <label>Tags (comma separated)<input value={f.tags} placeholder="sunset, landscape, travel" onChange={e=>setF({...f,tags:e.target.value})}/></label>
  {err&&<p className="err" role="alert">{err}</p>}
  <div className="btns"><button className="btn out" onClick={()=>img?setPrev(true):setErr('Choose a photo first.')}>Preview Before Publishing</button><button className="btn" onClick={pub}>Publish Photo</button></div>
  {prev&&<Modal onClose={()=>setPrev(false)}><div className="wm"><img src={img} alt="Preview"/></div><h3>{f.title||'Untitled'}</h3><p className="muted">{f.category} · {money(f.price)}</p></Modal>}</div>}

export function Profile(){
 const {s,set,say}=useStore();const [ed,setEd]=useState(false);const [f,setF]=useState(s.profile);const st=stats(s.photos)
 const av=async file=>{if(!file)return;if(!s.admin)return say('Only the admin can change the profile photo.');const a=await resize(file,300);set('profile',p=>({...p,avatar:a}));say('Profile photo updated.')}
 return <div className="wrap"><div className="prof"><label className="avwrap" title="Change profile photo"><Avatar name={s.profile.name} src={s.profile.avatar} size={120}/><span className="muted">Change photo</span><input type="file" accept="image/*" hidden onChange={e=>av(e.target.files[0])}/></label>
  <div><h1>{s.profile.name}</h1><p className="muted">{s.profile.bio}</p>
   <div className="stats sm"><div><b>{(s.profile.followers+(s.following?1:0)).toLocaleString()}</b><span>Followers</span></div><div><b>{st.Photos}</b><span>Photos</span></div><div><b>{st.Sales}</b><span>Sales</span></div><div><b>{st.Rating}</b><span>Avg Rating</span></div></div>
   <div className="btns"><button className={'btn'+(s.following?' out':'')} onClick={()=>{set('following',!s.following);say(s.following?'Unfollowed.':'Now following PHOTOHUB.')}}>{s.following?'Following':'Follow'}</button>{s.admin&&<button className="btn out" onClick={()=>{setF(s.profile);setEd(true)}}>Edit Profile</button>}
   {s.admin&&<Link className="btn out" to="/dashboard">Dashboard</Link>}<Link className="btn out" to="/orders">My Orders</Link></div></div></div>
  <Section t="My Photos"><PhotoGrid photos={live(s.photos)}/></Section>
  {ed&&<Modal onClose={()=>setEd(false)}><h2>Edit profile</h2><label>Name<input value={f.name} onChange={e=>setF({...f,name:e.target.value})}/></label><label>Bio<textarea value={f.bio} onChange={e=>setF({...f,bio:e.target.value})}/></label>
   <button className="btn" onClick={()=>{set('profile',p=>({...p,name:f.name,bio:f.bio}));say('Profile saved.');setEd(false)}}>Save changes</button></Modal>}</div>}

export function Favorites(){const {s,fav}=useStore();const ps=s.photos.filter(p=>s.favs.includes(p.id))
 return <div className="wrap"><Head t="My Favorites"/>{ps.length?<div className="masonry">{ps.map(p=><div key={p.id}><PhotoGridOne p={p}/><button className="btn sm out full" onClick={()=>fav(p.id)}>Remove Favorite</button></div>)}</div>:<Empty text="No favorite photos yet." btn="Explore Photos" to="/explore"/>}</div>}
import {PhotoCard} from '../components/ui'
const PhotoGridOne=({p})=><PhotoCard p={p}/>

export function Cart(){const {s,removeCart,photo}=useStore();const items=s.cart.map(photo).filter(Boolean);const total=sum(items,p=>p.price)
 if(!items.length)return <div className="wrap"><Head t="Cart"/><Empty text="Your cart is empty." btn="Explore Photos" to="/explore"/></div>
 return <div className="wrap"><Head t="Cart"/><div className="split"><div>{items.map(p=><div className="line" key={p.id}><img src={p.image} alt={p.title}/><div><h3>{p.title}</h3><b>{money(p.price)}</b></div><button className="ghost" onClick={()=>removeCart(p.id)}>Remove</button></div>)}</div>
  <aside className="panel"><h3>Order Summary</h3><div className="row"><span>Subtotal</span><span>{money(total)}</span></div><div className="row tot"><span>Total</span><span>{money(total)}</span></div>
  <Link className="btn full" to="/checkout">Proceed to Checkout</Link><Link className="btn out full" to="/explore">Continue Shopping</Link></aside></div></div>}

function KHQR(){const c=[];for(let y=0;y<25;y++)for(let x=0;x<25;x++){const f=(x<8&&y<8)||(x>16&&y<8)||(x<8&&y>16);if(!f&&((x*7+y*13+x*y)%5<2))c.push(<rect key={x+'-'+y} x={x} y={y} width="1" height="1"/>)}
 const fi=(x,y)=><g key={x+'_'+y}><rect x={x} y={y} width="7" height="7"/><rect x={x+1} y={y+1} width="5" height="5" fill="#fff"/><rect x={x+2} y={y+2} width="3" height="3"/></g>
 return <svg className="qr" viewBox="-1 -1 27 27" role="img" aria-label="Demo KHQR code"><rect x="-1" y="-1" width="27" height="27" fill="#fff"/>{c}{fi(0,0)}{fi(18,0)}{fi(0,18)}</svg>}
export function Checkout(){const {s,pay,photo,say}=useStore();const [email,setEmail]=useState('');const [done,setDone]=useState(null);const items=s.cart.map(photo).filter(Boolean);const total=sum(items,p=>p.price)
 if(done)return <div className="wrap narrow"><div className="panel center"><h1>Payment Successful ✓</h1><p className="muted">Demo payment · Order ID</p><h2>{done.id}</h2>
  {done.items.map(photo).filter(Boolean).map(p=><div className="line" key={p.id}><img src={p.image} alt={p.title}/><div><h3>{p.title}</h3></div><button className="btn sm" onClick={()=>download(p.full,p.title,say)}>Download Photo</button></div>)}
  <Link className="btn out" to="/orders">My Orders</Link></div></div>
 if(!items.length)return <div className="wrap"><Head t="Checkout"/><Empty text="Your cart is empty." btn="Explore Photos" to="/explore"/></div>
 return <div className="wrap"><Head t="Checkout" sub="Demo Payment — no real money is charged."/><div className="split"><div className="panel center"><h3>KHQR · Demo Payment</h3><KHQR/><p>Scan the KHQR code using your banking app.</p><p className="muted">This is a demo. Scanning does nothing.</p>
  <label>Customer email<input type="email" required value={email} placeholder="you@example.com" onChange={e=>setEmail(e.target.value)}/></label>
  <button className="btn full" onClick={()=>{if(!/\S+@\S+\.\S+/.test(email))return say('Enter a valid email.');setDone(pay(email))}}>I Have Paid</button></div>
  <aside className="panel"><h3>Order Summary</h3>{items.map(p=><div className="line sm" key={p.id}><img src={p.image} alt={p.title}/><span>{p.title}</span><b>{money(p.price)}</b></div>)}
  <div className="row"><span>Subtotal</span><span>{money(total)}</span></div><div className="row tot"><span>Total</span><span>{money(total)}</span></div></aside></div></div>}

export function Orders(){const {s,photo,say,removeOrder,removeOrderItem}=useStore();const [rc,setRc]=useState(null);const [ask,setAsk]=useState(null)
 return <div className="wrap"><Head t="My Orders" sub="Your purchased photos. Download the original any time."/>
 {s.orders.length===0?<Empty text="You haven't purchased any photos yet." btn="Explore Photos" to="/explore"/>:<div className="list">{s.orders.map(o=>{const L=linesOf(o,photo);return <div className="panel" key={o.id}>
  <div className="row"><div><h3>{o.id}</h3><span className="muted">{fdate(o.date)} · <span className="ok">{o.status}</span></span></div><b>{money(sum(L,l=>l.price))}</b></div>
  {L.map(l=>{const q=photo(l.id);return <div className="line sm" key={l.id}>{q?<img src={q.image} alt={l.title}/>:<span className="th"/>}<span>{l.title}</span><b>{money(l.price)}</b>
   <button className="btn sm" disabled={!q} onClick={()=>download(q.full,l.title,say)}>Download</button><button className="btn sm out" onClick={()=>setAsk({o:o.id,p:l.id})}>Delete</button></div>})}
  <div className="btns"><button className="btn sm out" onClick={()=>setRc(o)}>View Receipt</button><button className="btn sm out" onClick={()=>setAsk({o:o.id})}>Delete Order</button></div></div>})}</div>}
 {rc&&<Receipt o={s.orders.find(x=>x.id===rc.id)||rc} onClose={()=>setRc(null)}/>}
 {ask&&<Confirm text={ask.p?'Delete this purchased photo from your orders?':'Delete this whole order and its receipt?'} onYes={()=>{ask.p?removeOrderItem(ask.o,ask.p):removeOrder(ask.o);setAsk(null)}} onNo={()=>setAsk(null)}/>}</div>}

export function Dashboard(){const {s}=useStore();const top=[...s.photos].sort((a,b)=>b.sales-a.sales).slice(0,5)
 return <div className="wrap"><Head t="My Dashboard"/><Stats keys={['Photos','Sales','Revenue','Views','Likes','Rating']}/>
  <div className="btns"><Link className="btn" to="/sell">Upload Photo</Link><Link className="btn out" to="/my-photos">View My Photos</Link><Link className="btn out" to="/orders">View Orders</Link><Link className="btn out" to="/profile">Edit Profile</Link></div>
  <Section t="Recent Sales">{top.map(p=><div className="line sm" key={p.id}><img src={p.image} alt={p.title}/><span>{p.title}</span><span className="muted">{p.sales} sales</span><b>{money(p.sales*p.price)}</b></div>)}</Section>
  </div>}
