export const money=n=>'$'+n.toLocaleString()
export const fdate=d=>new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})
export async function download(url,name,say){
 try{const b=await (await fetch(url)).blob();const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name+'.'+(b.type.includes('png')?'png':'jpg');a.click()}
 catch{window.open(url,'_blank')}
 say&&say('Photo downloaded.')}
export function resize(file,max=1600){return new Promise((res,rej)=>{const r=new FileReader();r.onerror=rej
 r.onload=()=>{const i=new Image();i.onload=()=>{const k=Math.min(1,max/Math.max(i.width,i.height));const c=document.createElement('canvas')
  c.width=i.width*k;c.height=i.height*k;c.getContext('2d').drawImage(i,0,0,c.width,c.height)
  res(c.toDataURL(file.type==='image/png'?'image/png':'image/jpeg',.85))};i.onerror=rej;i.src=r.result};r.readAsDataURL(file)})}
