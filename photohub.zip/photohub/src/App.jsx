import {Routes,Route,useLocation} from './router'
import {useEffect} from 'react'
import {Navbar,Footer,Toast} from './components/ui'
import * as P from './pages/pages'
export default function App(){
 const {pathname}=useLocation();useEffect(()=>{scrollTo(0,0)},[pathname])
 return <><Navbar/><main key={pathname} className="page"><Routes>
  <Route path="/" element={<P.Home/>}/><Route path="/explore" element={<P.Explore/>}/><Route path="/photo/:id" element={<P.PhotoDetails/>}/>
  <Route path="/my-photos" element={<P.Guard><P.MyPhotos/></P.Guard>}/><Route path="/sell" element={<P.Guard><P.SellPhoto/></P.Guard>}/><Route path="/admin" element={<P.AdminLogin/>}/><Route path="/profile" element={<P.Profile/>}/>
  <Route path="/favorites" element={<P.Favorites/>}/><Route path="/cart" element={<P.Cart/>}/><Route path="/checkout" element={<P.Checkout/>}/>
  <Route path="/orders" element={<P.Orders/>}/><Route path="/dashboard" element={<P.Guard><P.Dashboard/></P.Guard>}/><Route path="/reviews" element={<P.Reviews/>}/>
  <Route path="*" element={<P.Explore/>}/></Routes></main><Footer/><Toast/></>}
