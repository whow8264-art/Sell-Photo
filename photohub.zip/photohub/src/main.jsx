import React from 'react'
import {createRoot} from 'react-dom/client'
import {HashRouter} from './router'
import {Provider} from './hooks/useStore'
import App from './App'
import './styles/main.css'
createRoot(document.getElementById('root')).render(<HashRouter><Provider><App/></Provider></HashRouter>)
