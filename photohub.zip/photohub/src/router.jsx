import {createContext,useContext,useSyncExternalStore,Children} from 'react'
// Tiny router (no `new URL`): works from file://, iframes and previews. Hash is kept in sync when allowed.
let cur=location.hash.slice(1)||'/';const ls=new Set();const emit=()=>ls.forEach(f=>f())
addEventListener('hashchange',()=>{cur=location.hash.slice(1)||'/';emit()})
export const go=to=>{cur=to;try{location.hash=to}catch{};emit()}
const sub=cb=>{ls.add(cb);return()=>ls.delete(cb)}
const parse=h=>{const i=h.indexOf('?');return{pathname:(i<0?h:h.slice(0,i))||'/',search:i<0?'':h.slice(i)}}
export const useLocation=()=>parse(useSyncExternalStore(sub,()=>cur))
export const HashRouter=({children})=>children
export const useNavigate=()=>go
const P=createContext({})
export const useParams=()=>useContext(P)
export function useSearchParams(){const {pathname,search}=useLocation()
 return [new URLSearchParams(search),o=>{const q=new URLSearchParams(o).toString();go(pathname+(q?'?'+q:''))}]}
const click=(to,onClick)=>e=>{onClick&&onClick(e);if(e.defaultPrevented||e.metaKey||e.ctrlKey||e.shiftKey||e.button)return;e.preventDefault();go(to)}
export const Link=({to,children,onClick,...r})=><a href={'#'+to} onClick={click(to,onClick)} {...r}>{children}</a>
export function NavLink({to,end,children,onClick,...r}){const {pathname}=useLocation()
 const on=end?pathname===to:pathname.startsWith(to);return <a href={'#'+to} onClick={click(to,onClick)} className={on?'active':''} aria-current={on?'page':undefined} {...r}>{children}</a>}
export const Route=()=>null
export function Routes({children}){const {pathname}=useLocation();const segs=pathname.split('/').filter(Boolean)
 for(const c of Children.toArray(children)){const {path,element}=c.props;if(path==='*')return element
  const ps=path.split('/').filter(Boolean);if(ps.length!==segs.length)continue
  const params={};if(ps.every((p,i)=>p[0]===':'?(params[p.slice(1)]=decodeURIComponent(segs[i]),true):p===segs[i]))return <P.Provider value={params}>{element}</P.Provider>}
 return null}
